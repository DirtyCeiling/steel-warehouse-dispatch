import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment, Text } from '@react-three/drei'
import { EffectComposer, Bloom } from '@react-three/postprocessing'
import { useWarehouseStore } from '@/store/warehouseStore'
import type { SteelCoil } from '@/types'
import { Span3D } from './Span'

interface WarehouseSceneProps {
  onCoilClick: (coil: SteelCoil) => void
}

export function WarehouseScene({ onCoilClick }: WarehouseSceneProps) {
  const { warehouse, locations, coils } = useWarehouseStore()
  
  return (
    <Canvas
      camera={{ position: [0, 30, 50], fov: 60 }}
      style={{ background: '#0a0f18' }}
    >
      <ambientLight intensity={0.3} />
      <directionalLight 
        position={[50, 50, 50]} 
        intensity={1}
        castShadow
      />
      <pointLight position={[-30, 20, 0]} intensity={0.5} color="#ff6b35" />
      <pointLight position={[30, 20, 0]} intensity={0.5} color="#4caf50" />
      
      <group position={[0, 0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
          <planeGeometry args={[200, 200]} />
          <meshStandardMaterial color="#0a0f18" metalness={0.1} roughness={0.9} />
        </mesh>
        
        {warehouse.spans.map((span, index) => {
          const offsetX = (index - 1) * 12
          return (
            <Span3D
              key={span.id}
              span={span}
              locations={locations}
              coils={coils}
              onCoilClick={onCoilClick}
              offsetX={offsetX}
            />
          )
        })}
        
        <Text
          position={[-12, 5, -15]}
          fontSize={1.5}
          color="#ff6b35"
          font="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&display=swap"
        >
          {warehouse.spans[0]?.name}
        </Text>
        <Text
          position={[0, 5, -15]}
          fontSize={1.5}
          color="#4caf50"
          font="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&display=swap"
        >
          {warehouse.spans[1]?.name}
        </Text>
        <Text
          position={[12, 5, -15]}
          fontSize={1.5}
          color="#2196f3"
          font="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&display=swap"
        >
          {warehouse.spans[2]?.name}
        </Text>
      </group>
      
      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        minDistance={10}
        maxDistance={100}
        maxPolarAngle={Math.PI / 2.2}
      />
      
      <EffectComposer>
        <Bloom luminanceThreshold={0.5} luminanceSmoothing={0.9} height={300} intensity={0.5} />
      </EffectComposer>
      
      <Environment preset="warehouse" />
    </Canvas>
  )
}
